import os
import re
import logging
import yt_dlp
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

# ─── الإعدادات ───
TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", 8828210338:AAHFEzHiYWrcfXQ0A7_rFF6oA8m9-UwY7kk "")

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)
logger = logging.getLogger(__name__)

# ─── أوامر البوت ───
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "👋 أهلاً بك في بوت تحميل TikTok!\n\n"
        "📌 أرسل لي رابط فيديو TikTok وأنا أحمله لك بدون علامة مائية.\n\n"
        "💡 اضغط Share → Copy Link في التطبيق"
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "📖 طريقة الاستخدام:\n"
        "1️⃣ افتح TikTok\n"
        "2️⃣ اضغط Share → Copy Link\n"
        "3️⃣ أرسل الرابط هنا"
    )

# ─── التحقق من رابط TikTok ───
def is_tiktok_url(text: str) -> bool:
    patterns = [
        r"https?://(www\.)?tiktok\.com/@[\w.-]+/video/\d+",
        r"https?://(www\.)?tiktok\.com/t/\w+",
        r"https?://vm\.tiktok\.com/\w+",
        r"https?://vt\.tiktok\.com/\w+",
    ]
    return any(re.search(p, text) for p in patterns)

# ─── استخراج رابط الفيديو بدون علامة مائية ───
def extract_tiktok_video(url: str):
    """
    يستخدم yt-dlp لاستخراج رابط الفيديو المباشر بدون علامة مائية
    """
    try:
        ydl_opts = {
            'format': 'best',
            'quiet': True,
            'no_warnings': True,
        }
        
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            
            # استخراج رابط الفيديو المباشر
            video_url = info.get('url')
            title = info.get('title', 'TikTok Video')
            thumbnail = info.get('thumbnail')
            duration = info.get('duration')
            
            if video_url:
                return {
                    "success": True,
                    "video_url": video_url,
                    "title": title,
                    "thumbnail": thumbnail,
                    "duration": duration
                }
            else:
                return {"success": False, "error": "لم أجد رابط الفيديو"}
                
    except Exception as e:
        logger.error(f"yt-dlp error: {e}")
        return {"success": False, "error": f"خطأ في التحميل: {str(e)}"}

# ─── معالجة الرسائل ───
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    
    if not is_tiktok_url(text):
        await update.message.reply_text(
            "❌ هذا ليس رابط TikTok صحيح!\n\n"
            "📌 أرسل رابط من التطبيق مباشرة:\n"
            "اضغط Share → Copy Link"
        )
        return
    
    # إرسال رسالة "جاري التحميل"
    processing_msg = await update.message.reply_text("⏳ جاري استخراج الفيديو...")
    
    try:
        result = extract_tiktok_video(text)
        
        if not result["success"]:
            await processing_msg.edit_text(f"❌ {result['error']}")
            return
        
        await processing_msg.edit_text("📤 جاري إرسال الفيديو...")
        
        # إرسال الفيديو
        await update.message.reply_video(
            video=result["video_url"],
            caption=f"✅ {result['title'][:200]}\n\n🤖 بوت تحميل TikTok",
            supports_streaming=True
        )
        
        # حذف رسالة التحميل
        await processing_msg.delete()
        
    except Exception as e:
        logger.error(f"Error: {e}")
        await processing_msg.edit_text(
            "❌ حدث خطأ أثناء التحميل.\n"
            "🔄 جرب رابط آخر أو تأكد من أن الفيديو عام (Public)."
        )

# ─── التشغيل الرئيسي ───
def main():
    if not TOKEN:
        logger.error("TELEGRAM_BOT_TOKEN غير موجود!")
        return
    
    application = Application.builder().token(TOKEN).build()
    
    # الأوامر
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    
    # الرسائل النصية
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    
    logger.info("✅ البوت يعمل...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
